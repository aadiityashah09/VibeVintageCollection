<?php
// Database connection settings
$host = 'localhost';       // Hostname (e.g., localhost)
$username = 'root';        // MySQL username
$password = '';            // MySQL password
$database = 'vibevintage'; // Database name

// Create a connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Optional: Uncomment the line below to debug successful connection
// echo "Connected successfully";
?>
