<header>
    <h1>VibeVintage Collection</h1>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="account.php">My Account</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>
