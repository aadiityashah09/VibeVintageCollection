-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2025 at 08:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vibevintage`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES
(3, 'admin', 'harihar', '2024-11-22 15:54:28');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kids_collection`
--

CREATE TABLE `kids_collection` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kids_collection`
--

INSERT INTO `kids_collection` (`id`, `name`, `price`, `description`, `created_at`) VALUES
(1, 'Sweatshirt for boys', 499.00, 'Kids Dress for Boys | Boy\'s Cotton full Sleeves Printed Sweatshirt and Pant Set | Sweatshirt and Joggers Combo Clothing Trendy Dress for Kids Boys', '2024-11-22 13:04:39'),
(2, 'Full Sleeve Sweatshirt', 679.00, 'Boys Full Sleeves Sweatshirt Cotton Graphic Printed Designs Tees | Latest Stylish Sweat T Shirt | Hypoallergenic Breathable Skin Friendly Fabric', '2024-11-22 13:07:48'),
(3, 'BTS Fancy Set for Girls', 599.00, '100% Cotton Fancy Set of top and Rayon Palazzo for Kids and Girls | Age_4-17 Years', '2024-11-22 13:09:03'),
(4, 'Madara Uchiha Sweatshirt', 579.00, 'Anime Hoodie for Boys Naruto Series Madara Uchiha Front and Back Printed Hoodies Hooded Sweatshirt Best Winter Wear', '2024-11-22 13:10:30'),
(5, 'Lahenga Choli for girls', 999.00, 'New latest Girl\'s Tissue checks readymade Lehenga choli for girls dress', '2024-11-22 13:11:35'),
(6, 'Boys Clothing Set (3 Piece)', 979.00, 'Boys Clothing Set 3 Piece Dress for Boys, Set of Coat, Pant & Shirt, Ideal for Wedding and Birthday', '2024-11-22 13:13:21'),
(7, 'Girls Denim Jeans', 945.00, 'Girls Denim Jeans Set, 3/4 Sleeves Jacket and Jeans Pants', '2024-11-22 13:14:40'),
(8, 'Girls Gown Frock', 985.00, 'Girls\' Gown Frock', '2024-11-22 13:15:43'),
(9, 'Full Sleeve Shirt (Black)', 349.00, 'Stylish Boys Cotton Printed Full Sleeve T-Shirt (Black)', '2024-11-22 13:17:16'),
(10, 'Kids Waistcoat and Pants for Boys', 599.00, 'Kids T-Shirt, Waistcoat and Pant for Boys', '2024-11-22 13:22:29'),
(16, 'Kurta and Pant set for Girls', 599.00, 'Kurta and Pant set for Girls', '2024-11-22 17:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `men_collection`
--

CREATE TABLE `men_collection` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `men_collection`
--

INSERT INTO `men_collection` (`id`, `name`, `price`, `image`, `description`) VALUES
(18, 'Men Office Wear', '349', '', 'Men\'s Cotton Blend Stitched Solid Full Sleeve Slim Fit Shirt'),
(19, 'Casual Shirt for Men', '479', '', 'Casual Shirt for Men|| Shirt for Men|| Men Stylish Shirt (Rib-Shirt)'),
(20, 'Winter Jacket', '599', '', 'Winter Jacket for Men || Quilted Jackets for Men & Boys || Regular Fit Jacket For Casual Wear'),
(21, 'Hoodie', '699', '', 'Trendy Men\'s Hoodie'),
(23, 'Stylish Shirt for Men', '428', '', 'Casual Shirt for Men || Shirt for Men Latest Stylish || Men Stylish Shirt || Men Solid Plain Shirt'),
(24, 'Half Sleeve T Shirt ', '409', '', 'T-Shirt | T-Shirt for Men | Polo T Shirt for Men | Casual T Shirt for Men | Men T Shirt | Men T Shirts Stylish Latest | Half Sleeve T Shirt'),
(25, 'Regular Fit Polo', '719', '', 'Men\'s Regular Fit Polo'),
(26, 'Marvel Superhero Shirt', '718', '', 'Marvel Men\'s Printed Regular Fit T-Shirt'),
(27, 'Marvel Captain Shield Shirt', '609', '', 'Marvel Captain\'s Shield T Shirt'),
(28, 'MoonKnight T-Shirt', '1500', '', 'Men\'s Marvel Printed 100% Cotton T-Shirt - Regular Fit, Round Neck, Half Sleeves - Moon Knight'),
(29, 'Jeans for Men', '1299', '', 'Relaxing Jeans for Men (Blue)'),
(30, 'Black Jeans', '1179', '', 'Comfortable Black Jeans for Men');

--
-- Triggers `men_collection`
--
DELIMITER $$
CREATE TRIGGER `update_product_image` AFTER UPDATE ON `men_collection` FOR EACH ROW BEGIN
    -- Check if the image field is updated
    IF OLD.image <> NEW.image THEN
        -- Update the product_images table with the new image
        UPDATE product_images
        SET image_path = NEW.image
        WHERE product_id = NEW.id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `shipping_fee` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `address`, `email`, `phone`, `total_price`, `shipping_fee`, `total_amount`, `payment_method`, `order_date`, `created_at`, `customer_id`, `user_id`) VALUES
(17, '', '', '', '', 888.50, 50.00, 938.50, 'COD', '2025-05-09 15:17:00', '2025-05-09 15:17:00', NULL, 10),
(18, '', '', '', '', 499.00, 50.00, 549.00, 'COD', '2025-07-07 06:19:18', '2025-07-07 06:19:18', NULL, 9);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image_path`) VALUES
(1, 14, 'uploads/regularfit1.jpg'),
(2, 14, 'uploads/regularfit2.jpg'),
(3, 18, 'uploads/officewear1.jpg'),
(4, 18, 'uploads/officewear2.jpg'),
(5, 19, 'uploads/mentshirt1.jpg'),
(6, 20, 'uploads/winterjacket.jpg'),
(7, 21, 'uploads/hoodie2.jpg'),
(8, 22, 'uploads/regularfit1.jpg'),
(9, 22, 'uploads/regularfit2.jpg'),
(10, 23, 'uploads/stylishshirt1.jpg'),
(11, 23, 'uploads/stylishshirt2.jpg'),
(12, 24, 'uploads/tshirt1.jpg'),
(13, 24, 'uploads/tshirt2.jpg'),
(14, 25, 'uploads/tshirt3.jpg'),
(15, 25, 'uploads/tshirt4.jpg'),
(16, 26, 'uploads/mc1.jpg'),
(17, 26, 'uploads/mc2.jpg'),
(18, 27, 'uploads/mc3.jpg'),
(19, 27, 'uploads/mc4.jpg'),
(20, 28, 'uploads/mc5.jpg'),
(21, 28, 'uploads/mc6.jpg'),
(22, 29, 'uploads/menjeans.jpg'),
(23, 29, 'uploads/menjeans2.jpg'),
(24, 30, 'uploads/blackjeans.jpg'),
(25, 30, 'uploads/blackjeans2.jpg'),
(26, 1, 'uploads/sweatshirtboys.jpg'),
(27, 2, 'uploads/sweatshirtboys2.jpg'),
(28, 2, 'uploads/sweatshirtboys3.jpg'),
(29, 3, 'uploads/btsfancyset.jpg'),
(30, 3, 'uploads/btsfancyset2.jpg'),
(31, 4, 'uploads/madaruchicha1.jpg'),
(32, 4, 'uploads/madaruchicha2.jpg'),
(33, 5, 'uploads/lahengacholi.jpg'),
(34, 6, 'uploads/weddingparty1.jpg'),
(35, 6, 'uploads/weddingparty2.jpg'),
(36, 7, 'uploads/denimset.jpg'),
(37, 7, 'uploads/denimset2.jpg'),
(38, 8, 'uploads/gownfrock1.jpg'),
(39, 8, 'uploads/gownfrock2.jpg'),
(40, 9, 'uploads/blacksleeve1.jpg'),
(41, 9, 'uploads/blacksleeve2.jpg'),
(42, 31, 'uploads/kidwaistcoat1.jpg'),
(43, 31, 'uploads/kidwaistcoat2.jpg'),
(44, 10, 'uploads/kidwaistcoat1.jpg'),
(45, 10, 'uploads/kidwaistcoat2.jpg'),
(46, 11, 'uploads/lastgirl.jpg'),
(47, 11, 'uploads/lastgirl2.jpg'),
(48, 12, 'uploads/lastgirl.jpg'),
(49, 12, 'uploads/lastgirl2.jpg'),
(50, 13, 'uploads/lastgirl.jpg'),
(51, 13, 'uploads/lastgirl2.jpg'),
(52, 14, 'uploads/lastgirl.jpg'),
(53, 14, 'uploads/lastgirl2.jpg'),
(54, 15, 'uploads/lastgirl.jpg'),
(55, 15, 'uploads/lastgirl2.jpg'),
(56, 16, 'uploads/lastgirl.jpg'),
(57, 16, 'uploads/lastgirl2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`, `email`) VALUES
(9, 'admin', 'harihar', 'admin', '2025-05-09 14:17:07', 'aadiityashah708@gmail.com'),
(10, 'aadiityashah', 'aadiityashah09', 'customer', '2025-05-09 15:16:16', 'aadiityashah@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `women_collection`
--

CREATE TABLE `women_collection` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) DEFAULT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `women_collection`
--

INSERT INTO `women_collection` (`id`, `name`, `price`, `image1`, `image2`, `description`) VALUES
(1, 'Women\'s Rayon Blend Anarkali Printed Kurta with Palazzo & Dupatta', 809.00, 'Women/Anarkaliset.jpg', NULL, 'Rayon Blend Anarkali set with Palazzo & Dupatta.'),
(2, 'Women\'s Rayon Blend Straight Embroidered Kurta with Pant & Dupatta', 909.00, 'Women/EmbroideredKurta.jpg', NULL, 'Straight Embroidered Kurta with matching Pant & Dupatta.'),
(3, 'Women\'s Rayon Blend Chikankari Embroidered Straight Kurta', 459.00, 'Women/ChikankariEmbroidered.jpg', NULL, 'Chikankari Embroidered Straight Kurta in Rayon Blend.'),
(4, 'Women\'s Cotton Blend Printed Anarkali Kurta with Pant & Dupatta', 859.00, 'Women/Anarkalikurta.jpg', NULL, 'Printed Cotton Blend Anarkali Kurta with Pant & Dupatta.'),
(5, 'Women\'s Rayon Blend Embroidered Straight Kurta with Pant & Dupatta', 689.00, 'Women/Rayonblendkurta.jpg', NULL, 'Rayon Blend Embroidered Straight Kurta with matching set.'),
(6, 'Women\'s Cotton Hooded Neck Sweatshirt', 649.00, 'Women/Hoodedsweatshirt.jpg', NULL, 'Comfortable and stylish hooded neck sweatshirt for women.'),
(7, 'Stretchable Viscose Ankle Length Leggings', 549.00, 'Women/leggings.jpg', NULL, 'Classic fit stretchable ankle-length leggings.'),
(8, 'Women\'s Soft Dola Silk Saree with Heavy Lace Blouse', 1999.00, 'Women/Sareewithblousepiece.jpg', NULL, 'Soft Dola Silk Saree with beautiful embroidery and lace blouse.'),
(9, 'Western Dress with Shrug', 629.00, 'Women/Westerndress1.jpg', 'Women/Westerndress2.jpg', 'Lycra Western Dress with matching shrug for a trendy look.'),
(10, 'Women\'s Bodycon Solid Dress', 399.00, 'Women/Soliddress.jpg', 'Women/Soliddress2.jpg', 'Elegant Bodycon solid dress for casual occasions.'),
(11, 'Regular Fit Mid Rise Jeans', 1575.00, 'Women/midraisejeans.jpg', 'Women/midraisejeans2.jpg', 'Classic Regular Fit Mid Rise Jeans for women.'),
(12, 'Antiviral Protective Cropped T-Shirt', 1348.00, 'Women/croppedtshirt.jpg', 'Women/croppedtshirt2.jpg', 'Stylish multicolor cropped t-shirt with antiviral finish.'),
(13, 'Full Sleeve Cotton Boyfriend Fit Shirt', 1500.00, 'Women/shirt1.jpg', 'Women/shirt2.jpg', 'Comfortable full sleeve collared boyfriend fit shirt.'),
(14, 'Women\'s Rayon Long Sleeve Double Pocket Shirt', 499.00, 'Women/shirt3.jpg', 'Women/shirt4.jpg', 'Casual long sleeve shirt with double pockets.'),
(15, 'Stylish Quilted Winter Jacket', 1125.00, 'Women/Jacket1.jpg', 'Women/Jacket2.jpg', 'Solid color stylish winter jacket with quilted design.'),
(16, 'Trendy Black Shorts', 479.00, 'uploads/shortswomen.jpg', 'uploads/shortswomen2.jpg', 'Black Shorts for Women');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `kids_collection`
--
ALTER TABLE `kids_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `men_collection`
--
ALTER TABLE `men_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `women_collection`
--
ALTER TABLE `women_collection`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kids_collection`
--
ALTER TABLE `kids_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `men_collection`
--
ALTER TABLE `men_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `women_collection`
--
ALTER TABLE `women_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `men_collection` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
