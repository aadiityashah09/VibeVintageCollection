-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2024 at 08:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vibevintage`
--

-- --------------------------------------------------------

--
-- Table structure for table `men_collection`
--

CREATE TABLE `men_collection` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `men_collection`
--

INSERT INTO `men_collection` (`id`, `name`, `price`, `image`, `description`) VALUES
(3, 'Winter Jacket', '1299', 'Men/menjacket.jpg', 'Clothing\'s Men Typography Hoodie Collections | 1000 Miles Print Hoodies for Men | Hooded Sweatshirt Best Winter Wear'),
(4, 'Casual Shirt for Men', '479', 'Men/menshirt1.jpg', 'Casual Shirt for Men|| Shirt for Men|| Men Stylish Shirt (Rib-Shirt)'),
(5, 'Winter Jacket', '599', 'Men/winterjacket.jpg', 'Winter Jacket for Men || Quilted Jackets for Men & Boys || Regular Fit Jacket For Casual Wear'),
(6, 'Hoodie', '699', 'Men/hoodie1.jpg', 'Trendy Men\'s Hoodie'),
(7, 'Full Sleeve Shirt', '349', 'Men/officewear1.jpg', 'Men\'s Cotton Blend Stitched Solid Full Sleeve Slim Fit Shirt');

--
-- Triggers `men_collection`
--
DELIMITER $$
CREATE TRIGGER `update_product_image` AFTER UPDATE ON `men_collection` FOR EACH ROW BEGIN
    -- Check if the image field is updated
    IF OLD.image <> NEW.image THEN
        -- Update the product_images table with the new image
        UPDATE product_images
        SET image_path = NEW.image
        WHERE product_id = NEW.id;
    END IF;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `men_collection`
--
ALTER TABLE `men_collection`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `men_collection`
--
ALTER TABLE `men_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
